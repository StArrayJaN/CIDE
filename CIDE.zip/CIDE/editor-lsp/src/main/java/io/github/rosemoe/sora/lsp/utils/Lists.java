package io.github.rosemoe.sora.lsp.utils;

import android.annotation.SuppressLint;
import android.os.Build;

import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.eclipse.lsp4j.CompletionItem;
import io.github.rosemoe.sora.lsp.editor.completion.LspCompletionItem;

public class Lists {
    @SuppressLint("NewApi")
    public static String toString(List<?> list) {
        return Arrays
                .toString(list
                .stream()
                .map(Object::toString)
                .collect(Collectors.toList())
                .toArray(new String[0]));
    }
    @SuppressLint("NewApi")
    public static String compeltionItemListToString(List<CompletionItem> list) {
            return Arrays
                    .toString(list
                            .stream()
                            .map(new Function<CompletionItem, String>() {
                                @Override
                                public String apply(CompletionItem completionItem) {
                                    StringBuilder str = new StringBuilder("detail:" + completionItem.getDetail() + "\n");
                                    str.append("label:" +completionItem.getLabel() + '\n');
                                    str.append("insertText:" + completionItem.getInsertText() + "\n");
                                    str.append("data:" + completionItem.getData() + "\n");
                                    return str.toString();
                                }
                            })
                            .collect(Collectors.toList())
                            .toArray(new String[0]));
    }
}
