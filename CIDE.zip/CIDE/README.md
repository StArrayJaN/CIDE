# LSPClient-Example
build:  
```
sh download
./gradlew assembleDebug
```
